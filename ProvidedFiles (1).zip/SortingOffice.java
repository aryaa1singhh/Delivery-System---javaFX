package studentprovidedfiles;

import java.util.ArrayList;

/**
 * Class to represent a Sorting Office object.
 * You will heavily edit this class and therefore no further comments have been added.
 * Ensure you add comments when submitting.
 */
public class SortingOffice {

    public int getX() {
        return 0;
    }

    public int getY() {
        return 0;
    }

    public boolean isInternational() {
        return false;
    }

    public ArrayList<SortingOffice> getConnections() {
        return null;
    }

}
