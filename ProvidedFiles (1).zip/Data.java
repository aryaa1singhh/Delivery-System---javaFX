package studentprovidedfiles;

import java.util.ArrayList;
import java.util.Stack;

/**
 * Class to hold data that is added to the "database".
 * You may add methods to this class.
 */
public class Data {

    /**
     * Attributes to save our data to the "database"
     */
    private static ArrayList<SortingOffice> sortingOffices = new ArrayList<>();
    private static Stack<Deliverable> deliverables = new Stack<>();
    private static Stack<Deliverable> processedDeliverables = new Stack<>();

    /**
     * Method to return the Stack of deliverables
     * @return stack of deliverables
     */
    public static Stack<Deliverable> getDeliverables(){
        return deliverables;
    }

    /**
     * Method to return the sorting offices
     * @return array list of sorting offices
     */
    public static ArrayList<SortingOffice> getSortingOffices(){
        return sortingOffices;
    }

    /**
     * Method to return the completed deliverables.
     * @return stack of completed deliverables.
     */
    public static Stack<Deliverable> getProcessedDeliverables(){
        return processedDeliverables;
    }

    /** DO NOT EDIT ANY CODE ABOVE THIS COMMENT. You may need to write additional methods below. **/


}
